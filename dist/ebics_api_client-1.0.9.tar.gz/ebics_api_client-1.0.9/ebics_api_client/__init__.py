"""
PyPI EBICS API Client module

Visit <https://github.com/andrew-svirin/ebics-api-client-python> for more information.
"""